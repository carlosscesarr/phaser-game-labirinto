var endState = {};
