var stage1State = {};
